



Try adding ```zsh``` to ```Dockerfile```:

```dockerfile
RUN apk --update add bash su-exec busybox-suid shadow 
```