from flask import Flask
from flask import request
from flask import Response
import datetime
import socket
import sys

app = Flask(__name__)

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def hello(path):
    lines = ["# Response"]
    lines.append("Service: " + sys.argv[1] or "not-specfied")
    lines.append("Host: " + socket.gethostname())
    lines.append("Time: " + str(datetime.datetime.time(datetime.datetime.now()))) 
    lines.append("")
    lines.append("# Request")
    for k,v in request.headers:
        lines.append(k + ':' + str(v))
    response = Response("\n".join(lines))
    response.headers['Content-Type'] = 'text/plain'
    return response
    
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8081, debug=True)
