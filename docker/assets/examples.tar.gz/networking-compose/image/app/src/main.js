var mysql = require('mysql');

var con = mysql.createConnection({
  host: "mysql",
  user: "root",
  password: "root"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});