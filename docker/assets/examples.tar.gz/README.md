


# Build and configure the project
$ docker run -it --rm  -w /srv/services -v $( pwd ):/srv/services -e BUILD_TYPE=dev -e BUILD_CONFIG=dev/munich -e LOCAL_UID=$( id -u ) -e LOCAL_GID=$( id -g ) -e LOCAL_CMD="/service build && /service config" viq/mip-gui-services:dev-latest /entrypoint

# Run Services container 
# NOTE: use -d to deamonize instead of --rm which removes cotnaienr after run
$ docker run -it --rm -e BUILD_TYPE=dev -e BUILD_CONFIG=dev/munich -v $( pwd ):/srv/services --name my_mip_gui_services viq/mip-gui-services:dev-latest


# Create Network to connect containers
$ docker network create my_mip_crm_network

# Connect CRM Container
$ docker network connect my_mip_crm_network my_mip_gui_crm

# Connect Service Container and alias by services (DNS AutoDiscovery! In CRM config we use http://services to access services!)
$ docker network connect --alias services my_mip_crm_network my_mip_gui_services

# And you can verify that by 
$ docker exec -it my_mip_gui_crm /bin/zsh
[container] $ ping services




ENTRYPOINT

RUN




### Start a container 

```bash
docker \
    # run a container based on an image \
    run \ 
    # interactive and allocate pseudo-terminal (TTY)\
    -it \
    # remove cotnainer after root-process inside container finished (exit)\
    --rm \
    # Mount local directory /conf to /etc/bind inside container \
    -v $(pwd)/conf:/etc/bind  \
    # Forward to network interface 10.67.232.8:54 port :53 from  container \
    -p 10.67.232.8:53:53  \
    # Same just for UDP \
    -p 10.67.232.8:53:53/udp  \
    # Give the ciontainer a beautiful name \
    --name bind-testing  \
    # Name of image \
    bind:testing  \
    # Command to be executed (otherwise will default to CMD in  Dockerfile ) \
    named -c /etc/bind/named.conf -g -u named -d 9 \
```

### Shell into the running container

```bash
docker \
   # Start a process within a running container \
  exec \
  # Container Name (or hash) \
  bind-testing \
  # Command \
  /bin/bash
```





If you shell into a container you always will be root!*
USER
- You write files as root to mounted filesystems!
- 

*except entrypoints wraps you


Entrypoint -- substitute environment variables


Don't start daemons!

Don't write logs to file inside containers!

Write logs to STDOUT and STDERR and/or use logging drivers!



https://docs.docker.com/engine/reference/builder


--compress --squash


udo docker exec -it CONTAINER_ID bash






# Alpine fixes
RUN chmod u+s /bin/ping




docker images -a --format "{{.ID}}" | head -1



test-argbuild:lates


command=/usr/sbin/nginx -g "daemon off; error_log /dev/stderr info;" -c /etc/nginx/nginx.conf



CMD sh -c 'if [ "$feature_enabled" = true ]; then echo "Feature activated"; else echo "Feature not activated"; fi'


entrypoint
development and production images
[ docker development best practices](https://docs.docker.com/develop/dev-best-practices/)

multistage biold
.dockerignore

build-dist-src
	docker run -it -v $(pwd)/src/:/share/srv/ test-argbuild:latest cp -pvr /share/srv/ /srv/ 

debuging failed build

alias docker-sliceshell="docker run -it --rm \$(docker image ls  -a --format "{{.ID}}" -f label=org.label-schema.name="test-failed-build" -f dangling=true | head -1) /bin/sh -c '\"\$(getent passwd \$(whoami) | cut -d: -f7)\"'"


Tricks:
docker run -it --rm -v $HOME/shared/:/shared/ alpine /bin/sh # does created both  $HOME/shared/:/shared/ if not existent
or docker container cp
docker run -it --rm alpine /bin/sh -c '"$(getent passwd $(whoami) | cut -d: -f7)"' 
docker run -it --rm alpine /bin/sh -c 'for i in /bin/zsh /bin/bash /bin/sh; do if test -e $i; then $i; exit $?; fi; done' 






ocjer                                                                                :(
130 ctang@refpad-16 ~/Projekte/L3/docker-intro/networking % docker history mysql:8                                                                :(
IMAGE               CREATED             CREATED BY                                      SIZE                COMMENT
ee1e8adfcefb        6 days ago          /bin/sh -c #(nop)  CMD ["mysqld"]               0B                  
<missing>           6 days ago          /bin/sh -c #(nop)  EXPOSE 3306/tcp 33060/tcp    0B                  
<missing>           6 days ago          /bin/sh -c #(nop)  ENTRYPOINT ["docker-entry…   0B                  
<missing>           6 days ago          /bin/sh -c ln -s usr/local/bin/docker-entryp…   34B                 
<missing>           6 days ago          /bin/sh -c #(nop) COPY file:59647006b032bcb2…   6.53kB              
<missing>           6 days ago          /bin/sh -c #(nop) COPY dir:110dcf1221c1f9432…   1.22kB              
<missing>           6 days ago          /bin/sh -c #(nop)  VOLUME [/var/lib/mysql]      0B                  
<missing>           6 days ago          /bin/sh -c {   echo mysql-community-server m…   369MB               
<missing>           6 days ago          /bin/sh -c echo "deb http://repo.mysql.com/a…   56B                 
<missing>           6 days ago          /bin/sh -c #(nop)  ENV MYSQL_VERSION=8.0.12-…   0B                  
<missing>           6 days ago          /bin/sh -c #(nop)  ENV MYSQL_MAJOR=8.0          0B                  
<missing>           6 days ago          /bin/sh -c set -ex;  key='A4A9406876FCBD3C45…   25.3kB              
<missing>           6 days ago          /bin/sh -c apt-get update && apt-get install…   44.7MB              
<missing>           6 days ago          /bin/sh -c mkdir /docker-entrypoint-initdb.d    0B                  
<missing>           6 days ago          /bin/sh -c set -x  && apt-get update && apt-…   4.44MB              
<missing>           6 days ago          /bin/sh -c #(nop)  ENV GOSU_VERSION=1.7         0B                  
<missing>           6 days ago          /bin/sh -c apt-get update && apt-get install…   10.2MB              
<missing>           6 days ago          /bin/sh -c groupadd -r mysql && useradd -r -…   329kB               
<missing>           6 days ago          /bin/sh -c #(nop)  CMD ["bash"]                 0B                  
<missing>           6 days ago          /bin/sh -c #(nop) ADD file:f8f26d117bc4a9289…   55.3MB  



docker history mysql:8 --format "{{.CreatedBy}}" --no-trunc
/bin/sh -c #(nop)  CMD ["mysqld"]
/bin/sh -c #(nop)  EXPOSE 3306/tcp 33060/tcp
/bin/sh -c #(nop)  ENTRYPOINT ["docker-entrypoint.sh"]
/bin/sh -c ln -s usr/local/bin/docker-entrypoint.sh /entrypoint.sh # backwards compat
/bin/sh -c #(nop) COPY file:59647006b032bcb29e59fba419c45f9d14154b34df99013c41321e204048254c in /usr/local/bin/ 
/bin/sh -c #(nop) COPY dir:110dcf1221c1f9432c68c32a2465ef0b40994f401d5fae0b0de80025bcf839a5 in /etc/mysql/ 
/bin/sh -c #(nop)  VOLUME [/var/lib/mysql]
/bin/sh -c {   echo mysql-community-server mysql-community-server/data-dir select '';   echo mysql-community-server mysql-community-server/root-pass password '';   echo mysql-community-server mysql-community-server/re-root-pass password '';   echo mysql-community-server mysql-community-server/remove-test-db select false;  } | debconf-set-selections  && apt-get update && apt-get install -y mysql-community-client="${MYSQL_VERSION}" mysql-community-server-core="${MYSQL_VERSION}" && rm -rf /var/lib/apt/lists/*  && rm -rf /var/lib/mysql && mkdir -p /var/lib/mysql /var/run/mysqld  && chown -R mysql:mysql /var/lib/mysql /var/run/mysqld  && chmod 777 /var/run/mysqld
/bin/sh -c echo "deb http://repo.mysql.com/apt/debian/ stretch mysql-${MYSQL_MAJOR}" > /etc/apt/sources.list.d/mysql.list
/bin/sh -c #(nop)  ENV MYSQL_VERSION=8.0.12-1debian9

docker inspect mysql:8 | jq  -r ".[].ContainerConfig"



/docker-entrypoint-initdb.d
/usr/local/bin/docker-entrypoint.sh -> process process_init_file


empower docker contaienrs by infrastrcutre


S6-Overlay
https://github.com/just-containers/s6-overlay


https://github.com/just-containers/s6-overlay